# Stratum Praxis

Official hub for Stratum Praxis — practical AI automation, digital systems, business tools, and resources.

## Included files

- `index.html` — website structure and content
- `styles.css` — responsive visual design
- `script.js` — mobile menu and placeholder-link notice
- `robots.txt` — search-engine crawling rules
- `sitemap.xml` — basic sitemap

## Publish with GitHub Pages

1. Upload all files to the repository root.
2. Open **Settings**.
3. Select **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/ (root)**.
6. Click **Save**.

## Before the final launch

Replace placeholder values in `index.html` and `sitemap.xml`:

- `https://example.com/`
- Payhip URL
- Gumroad URL
- X URL
- YouTube URL
- GitHub profile or project URL
- Audit page URL
- Privacy Policy URL
- Terms URL
- Open Graph image URL

## Contact

stratumpraxis@gmail.com
